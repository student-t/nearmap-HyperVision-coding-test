#ifndef HISTOGRAMTEST_H
#define HISTOGRAMTEST_H

class HistogramTest
{
public:
    void run();
};

#endif
