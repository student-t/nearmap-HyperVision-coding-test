#ifndef HISTOGRAMWRITERTEST_H
#define HISTOGRAMWRITERTEST_H

class HistogramWriterTest
{
public:
    void run();
};

#endif
