#ifndef THREADCOORDTEST_H
#define THREADCOORDTEST_H

class ThreadCoordTest
{
public:
    void run();
};

#endif
